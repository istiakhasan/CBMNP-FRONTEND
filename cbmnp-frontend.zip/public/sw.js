// Push notifications
self.addEventListener('push', function (event) {
  if (event.data) {
    const data = event.data.json();
    const options = {
      body: data.body,
      icon: data.icon || '/icon.png',
      badge: '/badge.png',
      vibrate: [100, 50, 100],
      data: { dateOfArrival: Date.now(), primaryKey: '2' },
    };
    event.waitUntil(self.registration.showNotification(data.title, options));
  }
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  event.waitUntil(clients.openWindow('http://31.97.60.104:3000'));
});


self.addEventListener('install', (event) => {
  console.log('Service worker installed');

  self.skipWaiting();
});


self.addEventListener('fetch', (event) => {
  console.log('Fetching:', event.request.url);
});
